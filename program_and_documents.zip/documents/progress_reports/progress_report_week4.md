Progress Report: Week 3
=======================

## Overview

I read about Monte Carlo Tree Seach and implemented a bot that uses MCTS. Did not have time to make tests, but it seems to work. It was a busy week.

**Total time spent: 9h**

## What I learned

I learned the basics of the MCTS algorithm and that should not estimate the amount of time it takes to arrange a house party.

## Daily reports

Sunday: Refactoring or something

**Time spent: 1h**

Monday: Refactoring or something

**Time spent: 1h**

Tuesday: Made better heuristic for evaluating the board situation. Read about Monte Carlo Tree Search. Started implementing MCTS.

**Time spent: 3h**

Wednesday: Started implementing Monte Carlo Tree Search. Read a tutorial about it and coded along.

**Time spent: 2h**

Thursday: Read more about Monte Carlo Tree Search and draw some diagrams about how it works to help me understand it. Fixed the MCTS code wrote yesterday based on it. Run it and fixed couple of bugs that occured.

**Time spent: 2h**

Friday: Wrote documents.

**Time spent: 0h**
