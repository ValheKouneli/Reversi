Progress Report: Week 2
=======================

Made a simple AI for Reversi the first day. Rest of the week: bug fixing, lots and lots of refactoring and additional tests.

**Total time spent: 20h**

## Monday

Made a working command line interface application that let's one play Reversi against a simple computer AI.

**Time spent: 6h**

## Tuesday

Made tests. Fixed bugs.

**Time spent: 2h**

## Monday (Easter break)

Fixed bugs. Made minor changes. Made tests.

**Time spent: 3h**

## Thursday

Made my own List class and tests for it. Made my older code use it.

**Time spent: 1h**

## Friday

Refactoring. Made some improvements as per teacher's suggestions: BoardFactory and better List structure.

Made new classes that made testing and reading code easier.

**Time spent: 8h**
