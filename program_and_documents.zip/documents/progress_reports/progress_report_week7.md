Overview
========

I spent time making statistics and adding documentation.

***Total time spent: 23 h***

## Daily reports

Monday: made tests for classes under application. The project was running on Netbeans but was not runnable on command line. Spent a lot of the time studying things about gradle and was finally able to make both gradle run work and gradle independent running on command line work.

Time spent: 4h

Wednesday: Tried to make the program to draw a chart, charting how often MCTS Bot wins against Minimax AI with different depths.

Time spent: 3h

Thursday:  Got the chart drawing working. It was hard, because I haven't used javafx before and because I was so tired I kept making stupid mistakes without noticing them right away.
I spend a lot of time reading stuff about the javafx elements I was using, trying to make them display data better. Made a things where win percentages are written into a file.
Tested that things are working 'manually'.

Time spent: 7h

Friday: Spent time peer-reviewing other projects.

Time spent: 6h

Friday: Added javadoc and comments, updated all kinds of documents.

Time spent: 3h

