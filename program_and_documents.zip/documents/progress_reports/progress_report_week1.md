Progress Report: Week 0
=======================

Configured the programming environment.

**Time spent: 2,5h**
