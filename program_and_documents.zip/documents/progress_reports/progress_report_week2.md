Progress Report: Week 1
=======================

I refreshed my Java skills.

**Time spent: 40h**
